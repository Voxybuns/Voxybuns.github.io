.-----------------------------------------.
| CONTROLLER GLYPHS FOR AGTD (SD VERSION) |
'-----------------------------------------'

A set of input icons converted into Game Builder Garage textures, designed for use with the AGTD tools by Borri and Scrubz.
This set is compatible with the SD card version of AGTD. Copy the icons you need onto the root of the SD card, insert it back into the Arduino setup, and run AGTD. Enjoy your icons!

Iconset designed and provided by Voxy (voxy.space)